﻿using SampleProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.Model
{
    public interface IRepository 
    {
        bool Add(Transaction model);
    }
}
