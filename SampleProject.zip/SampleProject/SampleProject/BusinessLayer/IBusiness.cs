﻿using SampleProject.Model;
using SampleProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.BusinessLayer
{
    public interface IBusiness
    {
        bool Add(Transaction model);
    }
}
