﻿using SampleProject.Model;
using SampleProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.BusinessLayer
{
    public abstract class BusinessFactory
    {
        public static IPaymentGateway Create(Transaction paymentInfo)
        {
            if (paymentInfo != null && paymentInfo.Amount > 0 && paymentInfo.Amount <= 20)
                return new CheapPaymentGateway();
            else if (paymentInfo != null && paymentInfo.Amount > 20 && paymentInfo.Amount <= 500)
                return new ExpensivePaymentGateway();
            else if (paymentInfo != null && paymentInfo.Amount > 500)
                return new PremiumGateway();
            else
                return null;
        }

    }
}
