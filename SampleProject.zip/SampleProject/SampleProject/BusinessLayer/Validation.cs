﻿using SampleProject.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.BusinessLayer
{
    public class Validation
    {
        public bool ValidateTransaction(Transaction transaction)
        {
            if(string.IsNullOrEmpty(transaction.CreditCardNumber) == true || string.IsNullOrEmpty(transaction.CardHolder))
            {
                return false;
            }
            else if(transaction.ExpirationDate == null || transaction.ExpirationDate < DateTime.Now)
            {
                return false;
            }
            else if(transaction.Amount <= 0)
            {
                return false;
            }
            else if(!string.IsNullOrEmpty(transaction.SecurityCode))
            {
                int securityCode = 0;
                int.TryParse(transaction.SecurityCode, out securityCode);
                if(!(transaction.SecurityCode.Length == 3 && securityCode > 0))
                {
                    return false;
                }
            }
            return true;
        }
    }
}
