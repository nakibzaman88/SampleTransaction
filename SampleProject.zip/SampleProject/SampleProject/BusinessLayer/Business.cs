﻿using SampleProject.Model;
using SampleProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.BusinessLayer
{
    public class Business
    {
        IRepository repository = DataFactory.Create();
        public bool Add(Transaction model)
        {
            return  repository.Add(model);
        }
    }
}
