﻿using SampleProject.Model;
using SampleProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.ServiceLayer
{
    public interface IPaymentService
    {
        bool ProcessPayment(Transaction paymentInfo);
    }
}
