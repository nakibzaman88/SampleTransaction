﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SampleProject.BusinessLayer;
using SampleProject.Model;
using SampleProject.ServiceLayer;
using SampleProject.ViewModel;

namespace SampleProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        IPaymentService _IPaymentService;
        private readonly IMapper _mapper;
        public TransactionController(IPaymentService paymentService, IMapper mapper)
        {
            _IPaymentService = paymentService;
            _mapper = mapper;
        }

        [HttpPost]
        public ActionResult PostTransaction(PaymentInfo paymentInfo)
        {
            try
            {
                if(!ModelState.IsValid || paymentInfo == null)
                {
                    return BadRequest("Model is not correct");
                }
                Transaction transaction = _mapper.Map<Transaction>(paymentInfo);
                bool result = _IPaymentService.ProcessPayment(transaction);
                if (result)
                {
                    return Ok("Transaction completed");
                }
                else
                {
                    return BadRequest("Transaction failed");
                }
            }
            catch(Exception ee)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ee.Message);
            }
        }
    }
}
